example_string="ReadMyCourse"
# print(example_string[2:]) #==>adMyCourse
# print(example_string[-4:])
# print(example_string[-1:])

print(example_string[:4])
#start=0
#stop=4
#0-3

print(example_string[:-5])
print(example_string[:-2])

print(example_string[:])


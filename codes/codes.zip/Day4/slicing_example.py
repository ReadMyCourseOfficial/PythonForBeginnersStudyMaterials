example_string="Welcome"
print(example_string[1:4])
print(example_string[2:5]) 
print(example_string[3:4])


example_string="ReadMyCourse"
#   "R e a d M y C o u r s e"
#               -6-5-4-3-2-1 

print(example_string[-6:-3])
print(example_string[-5:-1])
#start=-6
#stop=-3 
#-6 --> (-3-1)==>-4
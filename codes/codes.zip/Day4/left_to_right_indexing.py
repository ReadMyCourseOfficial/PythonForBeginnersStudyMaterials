example_string="Welcome"
#               0123456
print(example_string[0])
print(example_string[4])


example_string="Welcome"
#              W e l c o m e
#             -7-6-5-4-3-2-1
print(example_string[-4])
print(example_string[-1])
print(example_string[-7])




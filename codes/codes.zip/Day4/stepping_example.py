example_string="AbCdEe"
print(example_string[::2])
print(example_string[1::2])
a='b'
print(type(a))

#True or False
a=10
result=a<9
print(result)
print(type(result))

marks1=10
marks2=20
result=marks1>marks2
print(result)
print(type(result))


# #stores messages,texts
# name="ReadMyCourse"
# print(name)
# print(type(name))

# #addition or concatination of two strings
# first_name="Anand"
# last_name="Kumar"
# name=first_name+last_name
# print(name)

# name=first_name+" "+last_name
# print(name)
# name=2
# name="Anand"
# print(name)


#string with single quote
name='ReadMyCourse'
print(name)

#triple quote
name="""Anand"""
print(name)

#string with more than one line
message="""Welcome to ReadMyCourse
Thanks"""
print(message)


# name="ReadMyCourse"==>{'R','e','a','d','M','y',..}
print(len(name))
name="abc"==>{'a','b','c'}
            123   124  125
            
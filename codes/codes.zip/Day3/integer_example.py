age=2
length=100
score1=200
score2=300
# result=score1+score2
result=score1-score2
print(age)
print(length)
print(type(age))
print(result)
marks=35.6
print(marks)
print(type(marks))

#addition example
marks1=45.5
marks2=34.6
added_marks=marks1+marks2
print(added_marks)
print(type(added_marks))

#sub
marks1=45.5
marks2=34.6
sub_marks=marks1-marks2
print(sub_marks)
print(type(sub_marks))

#multiplication
marks1=20.0
result=3*marks1
print(result)
print(type(result))

#addition b/w float and integer
marks1=10
marks2=10.6
result=marks2+marks1
print(result)
print(type(result))

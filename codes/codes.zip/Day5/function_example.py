example_sring="Welcome"
#upper method
result=example_sring.upper()
print(result)
print(example_sring)
#lower method
result=example_sring.lower()
print(result)
#title 
example_sring="welcome to ReadMyCourse"
result=example_sring.title()
print(result)
#find method
example_sring="Welcome"
result=example_sring.find("c")
print(result)
#replace method
example_sring="Wel*come"
result=example_sring.replace("*","#")
print(result)
#reverse the string
example_sring="Welocme"
result=example_sring[::-1]
print(result)




a=False
b=False
#not operator
result=not a
print(result)
#or operator
#if any of a and b is true then the result will be true

result=a or b
print(result)

#and operator
#if both a and b are true then the result will be true otherwise false
a=True
b=True
result=a and b
print(result)


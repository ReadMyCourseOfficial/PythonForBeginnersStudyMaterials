example_string="Welcome"
changed_string=example_string[0:2]+"X"+example_string[3:]
print(changed_string)

5,"U"
changed_string=example_string[0:5]+"U"+example_string[6:]
print(changed_string)
    


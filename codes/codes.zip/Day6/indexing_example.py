list_example=[1,2,3,4]
#             0 1 2 3
#             -4-3-2-1

print(list_example[-2])
print(list_example[2])


# # list_example=[1,2,3,4,1]
# # print(list_example.count(1))

# list_example=[1,2,3,4,1]
# # print(list_example.index(5))


# #clear
# list_example=[1,2,3,4]
# print(list_example.clear())
# print(list_example)

# #reverse
# list_example=[1,2,3,4]
# list_example.reverse()
# print(list_example)


# #sort 
# list_example=[1,2,4,3]
# list_example.sort()
# list_example.reverse()
# print(list_example)


# list_example=[1,2,3]
# list_example1=list_example
# list_example1[2]=9
# print(list_example1)
# print(list_example)

list_example=[1,2,3]
list_example1=list_example.copy()
list_example1[2]=9
print(list_example1)
print(list_example)

list_example=[1,2,3,4,5]
#             0 1 2 3 4
#list_name(start,stop)    
print(list_example[1:4])

# print("Message",end="**")
# print("This is my message 2")
# print("This is my fucntion")
print("This is message 1","This is message 2","This is message 3",sep="*")



#single line comment
#single line comment 2
#single line comment 3
print("Hello world")
"""
This is comment line 1
this is comment line 2
this is comment line 3
"""

